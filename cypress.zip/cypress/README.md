This Directory contains our end to end testing suite.

Note that functions that are prefixed with `_` include direct api interaction rather than UI interactions
