import {
  confirmSuccessfulPayment,
  enterTravelerDetails,
  fillInStripeForm,
  selectRoom,
  selectsRoomExtras,
} from '../../support/Common';
import {
  _selectReservationDatesLiveBooking,
  confirmUserDataLoaded,
  createAccountLiveBooking,
  enterGuestDashboard,
  entersLiveBooking,
} from '../../support/LiveBooking';
import { makeFakeUser } from '../../support/utils';

const DSAPI = Cypress.env('DSAPI');
const DSAPI_AWS = Cypress.env('DSAPI_AWS');

export function interceptAndAliasAllRequests() {
  const requests = {
    Register: `${DSAPI_AWS}/RegisterUser`,
    Authenticate: `${DSAPI_AWS}/AuthenticateUser`,
    GroupInfo: `${DSAPI_AWS}/groups/*`,
    Availability: `${DSAPI_AWS}/hotel/availability`,
    WeddingInfo: `${DSAPI_AWS}/groups/*/wedding`,
    Transfers: `${DSAPI_AWS}/transfer/hotelTransfersByCrmHotelId/*/1/0`,
    //Payment endpoints
    CaptureCharge: `${DSAPI_AWS}/stripe/capturecharge/*`,
    Recheck: `${DSAPI_AWS}/hotel/recheck`,
    Book: `${DSAPI_AWS}/hotel/book`,
    CreateRoom: `${DSAPI_AWS}/rooms/createRoom`,
    AddUserGroupInformation: `${DSAPI_AWS}/user/addUserGroupInformation/*/*/*`,
    CreatePayment: `${DSAPI_AWS}/payment/createPayment`,
    SignatureUpload: `${DSAPI_AWS}/payment/signature-upload`,
    // complete livebooking flow
    UserTrips: `${DSAPI_AWS}/user/userTrips/*`,
    Groups: `${DSAPI_AWS}/groups?groupIds=*`,
    Rooms: `${DSAPI_AWS}/rooms?roomIds=*`,
    //TODO: WE SHOULD NOT BE LOADING THE BELOW ENDPOINTS FOR GUESTS. FIX THIS
    GuestList: `${DSAPI_AWS}/groupleader/*/guestlist`,
    WeddingDetails: `${DSAPI_AWS}/groupleader/wedding-details`,
  };
  //iterate over requests and intercept and alias each request
  Object.keys(requests).forEach(alias => {
    cy.intercept(requests[alias], req => {
      console.log('Request body:', req.body);
    }).as(alias);
  });
}

const testUser = makeFakeUser();
const { firstName, email } = testUser;
const lastName = 'TESTBOOKING';

describe('Book Room No Transfer', () => {
  beforeEach(() => {
    cy.clearLocalStorage();
  });

  const groupId = '5f04047b-6b47-9773-9dd5-642b094618c9';

  it('can navigate through live booking with expected results', () => {
    interceptAndAliasAllRequests();
    entersLiveBooking(groupId);
    selectRoom('live-booking');
    enterTravelerDetails(testUser);
    cy.wait('@Transfers').its('response.statusCode').should('eq', 200);
    selectsRoomExtras({ roomExtras: true });
    cy.log('CONFIRMATION');
    cy.clickNextButton();
    cy.log('PAYMENT');
    createAccountLiveBooking({ firstName, lastName, email });
    fillInStripeForm({ firstName, lastName });
    confirmSuccessfulPayment();
    confirmUserDataLoaded();
    enterGuestDashboard();
  });
});
