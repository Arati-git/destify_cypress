import {
  interceptAndAliasAllRequests,
  entersSalesView,
  selectsDestination,
  selectsCity,
  selectsResort,
  selectsVenue,
  selectsPackage,
  selectsWeddingDate,
  selectsAlternateWeddingDate,
  createsAccount,
  entersGuestDetails,
  entersPreferences,
  entersProfileDetails,
  submitsPreferences,
  submitsWeddingRequest,
  confirmsSuccessfulWeddingRequest,
} from '../../support/SalesJourney';

//The same test as SubmitWeddingRequest, but user creates account when presented with modal window

//Functional Simplest Sales Journey Process through creating an account and submitting a wedding request.

describe('Submit Wedding Request Through Sales Journey', () => {
  it('Visits Site, Completes Step 1 of Sales Journey', () => {
    interceptAndAliasAllRequests();
    entersSalesView();
    selectsDestination();
    selectsCity();
    // selectsAnticipatedWeddingDate();
    selectsResort('static_pricing');
    selectsVenue();
    selectsPackage();
    selectsWeddingDate();
    selectsAlternateWeddingDate();
    createsAccount();
    entersProfileDetails();
    entersGuestDetails();
    entersPreferences();
    submitsPreferences();
    submitsWeddingRequest();
    confirmsSuccessfulWeddingRequest();
  });
});
