/*
Mimics Sales Lead behaviors of researching various Resorts, venues, and Hotels. 
Goes back and forth between pages with and without an account. 
*/
//Set up date formated as <Month Abbreviated> <Numerical Date of Day>, <Year> to be used to select different days on the calendar.
// Starting date is 364 days from today (approximately)
//HACK: This should be a command so it can be used in  other Cypress Tests.
const today = new Date();
const monthOptions = { month: 'long' };
const todayMonthLong = new Intl.DateTimeFormat('en-US', monthOptions).format(
  today,
);
var todayDate = today.getDate();
var todayYear = today.getFullYear();
todayYear++;
todayDate--;
const todayMonth = todayMonthLong.substring(0, 3);

describe('Submit Wedding Request Through Sales Journey', () => {
  it('Visits Site, Completes Step 1 of Sales Journey', () => {
    cy.log('Vists Site and starts Sales Journey');

    cy.visit(Cypress.config('baseUrl'));

    cy.get('[data-testid="sign-up-button-sign-up"]').click();

    cy.get(
      '[data-testid="sign-up-as-button-plan-my-destination-wedding"]',
    ).click();

    cy.intercept(
      'https://salesjourney-staging.destify-services.com/api/Country/*',
    ).as('Country');

    cy.clickNextButton('@Country');

    cy.log('Researches and Selects 3 Destinations');

    cy.get('[data-testid="card-button-see-more-0"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.get('[data-testid="card-button-see-more-2"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.scrollTo('bottom');

    cy.scrollTo('center');

    cy.get('[data-testid="card-button-see-more-5"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.scrollTo('top');

    cy.get('[data-testid="card-button-see-more-1"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.get('[data-testid="card-button-select-1"]').click();

    cy.get('[data-testid="card-button-select-2"]').click();

    cy.scrollTo('center');

    cy.get('[data-testid="card-button-select-5"]').click();

    cy.intercept(
      'https://salesjourney-staging.destify-services.com/api/City/*',
    ).as('City');

    cy.clickNextButton('@City');

    cy.log('Researches and selects 3 Cities');

    cy.scrollTo('bottom');

    cy.scrollTo('center');

    cy.get('[data-testid="card-button-see-more-5"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.get('[data-testid="card-button-select-5"]').click();

    cy.scrollTo('top');

    cy.get('[data-testid="card-button-see-more-1"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.get('[data-testid="card-button-select-1"]').click();

    cy.get('[data-testid="card-button-see-more-6"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.get('[data-testid="card-button-select-6"]').click();

    cy.intercept(
      'https://salesjourney-staging.destify-services.com/api/Resort/*',
    ).as('Resort');

    cy.clickNextButton('@Resort');

    cy.log('Enters Date and Researches Resorts');

    cy.get('[data-testid="anticipated-wedding-date-input-date"]').click();

    cy.get('.MuiButtonBase-root > [data-testid="ArrowDropDownIcon"]').click();

    cy.get(':nth-child(2) > .PrivatePickersYear-yearButton').click();

    cy.get('.MuiDialogActions-root > :nth-child(2)').click();

    cy.wait('@Resort').its('response.statusCode').should('eq', 200);

    cy.log('Goes Back to Destination');

    cy.get('[data-testid="sales-lead-button-back"]').click();

    cy.scrollTo('bottom');

    cy.get('[data-testid="sales-lead-button-back"]').click();

    cy.log('Research and Select New Destination and Test > 3 Selection Limit');

    cy.get('[data-testid="card-button-see-more-3"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.get('[data-testid="card-button-select-3"]').click();

    cy.get('[data-testid="app-alert-button-close"]').click();

    cy.get('[data-testid="card-button-select-1"]').click();

    cy.get('[data-testid="card-button-select-3"]').click();

    cy.clickNextButton('@City');

    cy.log('Research and Selects New Cities and Test > 3 Selection Limit');

    cy.get('[data-testid="card-button-select-0"]').click();

    cy.get('[data-testid="card-button-select-1"]').click();

    cy.get('[data-testid="card-button-select-3"]').click();

    cy.get('[data-testid="card-button-see-more-5"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.get('[data-testid="card-button-select-5"]').click();

    cy.get('[data-testid="app-alert-button-close"]').click();

    cy.get('[data-testid="card-button-select-0"]').click();

    cy.get('[data-testid="card-button-select-5"]').click();

    cy.clickNextButton('@Resort');

    cy.log('Researches Resorts, Validates > 3 Selections Limit');

    cy.scrollTo('bottom');

    cy.scrollTo('center');

    cy.scrollTo('top');

    cy.get('[data-testid="card-button-see-more-1"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.get('[data-testid="card-button-see-more-5"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.get('[data-testid="card-button-see-more-6"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.log('Compares Different Dates');

    cy.get('[data-testid="anticipated-wedding-date-input-date"]').click();

    cy.get('.MuiButtonBase-root > [data-testid="ArrowDropDownIcon"]').click();

    cy.get(':nth-child(2) > .PrivatePickersYear-yearButton').click();

    cy.get('.MuiMonthPicker-root > .MuiTypography-h5').click();

    cy.log(`Select Date for ${todayMonth} ${todayDate}, ${todayYear}`);

    var GetDate = `[aria-label="${todayMonth} ${todayDate}, ${todayYear}"]`;

    cy.get(GetDate).click();

    cy.get('.MuiDialogActions-root > :nth-child(2)').click();

    cy.wait('@Resort').its('response.statusCode').should('eq', 200);

    cy.scrollTo('bottom');

    cy.scrollTo('center');

    cy.scrollTo('top');

    cy.get('[data-testid="anticipated-wedding-date-input-date"]').click();

    cy.get('.MuiButtonBase-root > [data-testid="ArrowDropDownIcon"]').click();

    cy.get(':nth-child(2) > .PrivatePickersYear-yearButton').click();

    cy.get('.MuiMonthPicker-root > .MuiTypography-h5').click();

    todayDate++;
    todayDate++;

    GetDate = `[aria-label="${todayMonth} ${todayDate}, ${todayYear}"]`;

    cy.log(`Select Date for ${todayMonth} ${todayDate}, ${todayYear}`);

    cy.get(GetDate).click();

    cy.get('.MuiDialogActions-root > :nth-child(2)').click();

    cy.wait('@Resort').its('response.statusCode').should('eq', 200);

    cy.scrollTo('bottom');

    cy.scrollTo('center');

    cy.scrollTo('top');

    cy.log('Selects Resorts');

    cy.get('[data-testid="card-button-select-1"]').click();

    cy.get('[data-testid="card-button-select-3"]').click();

    cy.get('[data-testid="card-button-select-5"]').click();

    cy.intercept(
      'https://salesjourney-staging.destify-services.com/api/ResortVenue/*',
    ).as('ResortVenue');

    cy.clickNextButton('@ResortVenue');

    // cy.log('Proceeds as Guest');

    // cy.get('[data-testid="app-modal-button-proceed-as-guest"]').click();

    cy.log('Selects Venue.');

    cy.get('[data-testid="card-button-select-1"]').click();

    cy.intercept(
      'https://salesjourney-staging.destify-services.com/api/WeddingPackage/*',
    ).as('WeddingPackage');

    cy.clickNextButton('@WeddingPackage');

    cy.log('Research and Select Wedding Package');

    cy.get('[data-testid="card-button-see-more-0"]').click();

    cy.get('[data-testid="see-more-modal-button-close"]').click();

    cy.get('[data-testid="card-button-select-0"]').click();

    cy.intercept(
      'https://salesjourney-staging.destify-services.com/api/SalesLead/PreferredCeremonyTime',
    ).as('PreferredCeremonyTime');

    cy.clickNextButton('@PreferredCeremonyTime');

    cy.log('Select Time');

    cy.get('[data-testid="ceremony-time-button-time-1"]').click();

    cy.clickNextButton('@PreferredCeremonyTime');

    cy.log('Selects Alternate Date and Time');

    todayDate++;

    GetDate = `[aria-label="${todayMonth} ${todayDate}, ${todayYear}"]`;

    cy.log(`Select Date for ${todayMonth} ${todayDate}, ${todayYear}`);

    cy.get(GetDate).click();

    cy.get('[data-testid="ceremony-time-button-time-0"]').click();

    cy.clickNextButton();

    cy.wait(2000);
    // cy.get('[data-testid="app-modal-button-create-account"]').click();

    cy.log('End of test');
  });
});
