import { bookAWedding } from '../../support/SalesJourney';

import { makeFakeUser } from '../../support/utils';
import { faker } from '@faker-js/faker';

describe('Books a wedding through sales journey', () => {
  beforeEach(() => {
    cy.clearLocalStorage();
  });

  it('Books a wedding with a static priced, auto-approved resort with no transfers', () => {
    const { firstName, lastName, email } = makeFakeUser();
    bookAWedding({
      pricingType: 'static_pricing',
      firstName,
      lastName,
      email,
      roomExtras: false,
    });
  });
});
