import { bookAWedding } from '../../support/SalesJourney';

import { loginAs, makeFakeUser } from '../../support/utils';
import { changeUserRole } from '../../support/Admin';

describe('Books a wedding through sales journey', () => {
  beforeEach(() => {
    cy.clearLocalStorage();
  });

  it('Books a wedding with a static priced, auto-approved resort with no transfers', () => {
    const { firstName, lastName, email } = makeFakeUser();
    console.log({ email });
    bookAWedding({
      pricingType: 'static_pricing',
      firstName: firstName,
      lastName: lastName,
      email: email,
      roomExtras: true,
    });
    // loginAs(fakeUser, fakeUser);

    changeUserRole(email);

    cy.visit(Cypress.env('APP_URL'));
  });
});
