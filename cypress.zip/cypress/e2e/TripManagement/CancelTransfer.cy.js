// Cancels a Purchased Transfer.

//NOTE: Interceptions transferdetail, and hotelTransfersByCrmHotelId use a Room ID and Hotel ID. If user is changed, these may need to be updated as well.

//HACK: Validation for transfer confirmation and cancellation uses .titleWrapper. This is fragile. A testid should be added.
describe('Purchases Transfer and then cancels the transfer', () => {
  it('Logs In and Edits Traveler Information', () => {
    cy.log('Vists Site');

    cy.visit(Cypress.config('baseUrl'));

    cy.intercept(
      ' https://api.destify-services-staging.com/api/AuthenticateUser',
    ).as('Auth');

    cy.get('[data-testid="sign-up-button-log-in"]').click();

    cy.get('[data-testid="log-in-input-email"]').type(
      'Bobby_Stroman9190@gmail.com',
    );

    cy.get('[data-testid="log-in-input-password"]').type(
      'Bobby_Stroman9190@gmail.com',
    );

    cy.get('[data-testid="log-in-button-log-in"]').click();

    cy.wait('@Auth').its('response.statusCode').should('eq', 200);

    cy.url({ timeout: 10000 }).should('contain', '/home');

    cy.log('Navigates to Room Extras');

    cy.get('[data-testid="nav-tabs-trip-management"]').click();

    cy.get('[data-testid="menu-item-button-manage-room-extras"]').click();

    cy.intercept(
      'https://api.destify-services-staging.com/api/rooms/1f56e225-968e-d64d-3123-64188b3aa8ec/transferdetail',
    ).as('transferdetail');

    cy.intercept(
      'https://api.destify-services-staging.com/api/traveler/flight/details/*',
    ).as('flightdetails');

    cy.wait('@transferdetail', { timeout: 20000 }).then(interception => {
      console.log('trasfer', interception?.response?.body);
      const hasPurchasedTransfer = interception?.response?.body?.tzTransfers;

      console.log('trasfer', hasPurchasedTransfer);

      if (hasPurchasedTransfer === '0.00') {
        cy.log('Purchases Transfer');

        cy.intercept(
          'https://api.destify-services-staging.com/api/transfer/hotelTransfersByCrmHotelId/5579ccef-b468-7d77-7b07-5136aada2510/2/0',
        ).as('hotelTransfersByCrmHotelId');

        cy.get('[data-testid="room-extras-button-purchase-transfer"]').click();

        cy.get(
          '[data-testid="hotel-transfer-list-block-button-toggle-transfer-0"]',
        ).click();

        cy.get(
          '[data-testid="select-transfer-button-select-transfer"]',
        ).click();

        cy.get(
          '[data-testid="confirm-selected-transfer-checkbox-confirm"]',
        ).click();

        cy.intercept(
          'https://api.destify-services-staging.com/api/rooms/update/*',
        ).as('update');

        cy.get(
          '[data-testid="confirm-selected-transfer-button-confirm"]',
        ).click();
        cy.wait('@update').its('response.statusCode').should('eq', 200);

        cy.get('[data-testid="purchase-transfer-modal-button-close"]').click();
      }
    });

    cy.log('Cancel Purchased Transfer');

    cy.intercept(
      'https://api.destify-services-staging.com/api/rooms/update/*',
    ).as('update');

    cy.get('[data-testid="room-extras-button-cancel-transfer"]').click();

    cy.get(
      '[data-testid="transfer-cancel-confirm-modal-button-cancel-transfer"]',
    ).click();

    cy.wait('@update').its('response.statusCode').should('eq', 200);

    cy.get('[data-testid="app-alert-button-title"]').should(
      'contain',
      'Your cancellation is confirmed',
    ); //HACK

    cy.get('[data-testid="app-alert-button-close"]').click();

    cy.log('End of test');
  });
});
