//Tests basic functionality of editing guest contact information from My Rooms page

//HACK: Typing the email and phone into modal uses Nth child which is fragile.

const RunID = Math.floor(Math.random() * 10000);

describe('Edit Booking Information for 2 travelers in room', () => {
  it('Logs In and Edits Traveler Information', () => {
    cy.visit(Cypress.config('baseUrl'));

    cy.intercept(
      ' https://api.destify-services-staging.com/api/AuthenticateUser',
    ).as('Auth');

    cy.get('[data-testid="sign-up-button-log-in"]').click();

    cy.get('[data-testid="log-in-input-email"]').type('britini@travelzap.com');

    cy.get('[data-testid="log-in-input-password"]').type('britiniandben');

    cy.get('[data-testid="log-in-button-log-in"]').click();

    cy.wait('@Auth');

    // cy.url().should('contain', '/rooms');
    cy.get('[data-testid="nav-tabs-trip-management"]').click();

    cy.testid('menu-item-button-my-rooms').click();

    // Edits Traveler One Contact Information

    cy.intercept(
      'https://api.destify-services-staging.com/api/rooms/update/*',
    ).as('Update');

    cy.get('[data-testid="room-guests-button-guest-edit-0"]').click();

    cy.testid('edit-booking-information-modal-input-email')
      .clear()
      .type('ben+editTravelerOne@destify.com');

    cy.testid('edit-booking-information-modal-input-phone')
      .clear()
      .type('12345671111');

    cy.get(
      '[data-testid="edit-booking-information-modal-button-save"]',
    ).click();

    cy.wait('@Update').its('response.statusCode').should('eq', 200);

    cy.get('[data-testid="app-alert-button-close"]').click();

    // Edits Traveler Two Contact Information

    cy.intercept(
      'https://api.destify-services-staging.com/api/rooms/update/*',
    ).as('Update');

    cy.get('[data-testid="room-guests-button-guest-edit-1"]').click();

    cy.testid('edit-booking-information-modal-input-email')
      .clear()
      .type('britini+editTravelerTwo@destify.com');

    cy.testid('edit-booking-information-modal-input-phone')
      .clear()
      .type('12345672222');

    cy.get(
      '[data-testid="edit-booking-information-modal-button-save"]',
    ).click();

    cy.wait('@Update').its('response.statusCode').should('eq', 200);

    cy.get('[data-testid="app-alert-button-close"]').click();

    // Verifies information is updated

    cy.get('[data-testid="room-guests-button-guest-edit-0"]').click();

    cy.testid('edit-booking-information-modal-input-email').should(
      'have.value',
      'ben+editTravelerOne@destify.com',
    );

    cy.testid('edit-booking-information-modal-input-phone').should(
      'have.value',
      '12345671111',
    );

    cy.wait(1000);
    cy.get('[data-testid="app-modal-button-close"]').click();

    // Verify Second Traveler

    cy.get('[data-testid="room-guests-button-guest-edit-1"]').click();

    cy.testid('edit-booking-information-modal-input-email').should(
      'have.value',
      'britini+editTravelerTwo@destify.com',
    );

    cy.testid('edit-booking-information-modal-input-phone').should(
      'have.value',
      '12345672222',
    );

    cy.get('[data-testid="app-modal-button-close"] > svg').click();

    cy.log('FINISHED!');
  });
});
