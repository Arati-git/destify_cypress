//Tests basic functionality of Share This Room feature from the My Rooms screen

//TODO: Use guide https://www.cypress.io/blog/2021/05/11/testing-html-emails-using-cypress/ and `smtp-tester ` module to receive email and validate for invitation tests.

const RunID = Math.floor(Math.random() * 10000);

describe('Share this room for Room Manger and View and Pay', () => {
  it('Logs In and shares room', () => {
    cy.visit(Cypress.config('baseUrl'));

    cy.intercept(
      ' https://api.destify-services-staging.com/api/AuthenticateUser',
    ).as('Auth');

    cy.get('[data-testid="sign-up-button-log-in"]').click();

    cy.testid('log-in-input-email').type('britini@travelzap.com');

    cy.testid('log-in-input-password').type('britiniandben');

    cy.get('[data-testid="log-in-button-log-in"]').click();

    cy.wait('@Auth');

    cy.url().should('contain', '/home');

    cy.get('[data-testid="nav-tabs-trip-management"]').click();

    cy.get('[data-testid="menu-item-button-my-rooms"]').click();

    // Checks Share this Room for Room Manager

    cy.intercept(
      'https://api.destify-services-staging.com/api/roomaccess/create-invitation',
    ).as('Invitation');

    cy.get(
      '[data-testid="room-title-info-button-share-this-room"] > svg',
    ).click();

    cy.get('[data-testid="share-room-modal-input-first-name"]').type('Invite');

    cy.get('[data-testid="share-room-modal-input-last-name"]').type(
      'Room Manager',
    );

    cy.get('[data-testid="share-room-modal-input-email"]').type(
      `product+RMinviteTesting${RunID}@destify.com`,
    );

    cy.get(
      '[data-testid="share-room-modal-button-level-room-manager"]',
    ).click();

    cy.get('[data-testid="share-room-modal-button-send"]').click();

    cy.wait('@Invitation').its('response.statusCode').should('eq', 200);

    //TODO

    cy.get('[data-testid="app-alert-button-close"]').click();

    cy.get('[data-testid="app-modal-button-close"] > svg').click();

    // Checks Share this Room for View & Pay

    cy.intercept(
      'https://api.destify-services-staging.com/api/roomaccess/create-invitation',
    ).as('Invitation');

    cy.get(
      '[data-testid="room-title-info-button-share-this-room"] > svg',
    ).click();

    cy.get('[data-testid="share-room-modal-input-first-name"]').type('Invite');

    cy.get('[data-testid="share-room-modal-input-last-name"]').type('ViewPay');

    cy.get('[data-testid="share-room-modal-input-email"]').type(
      `product+VPinviteTesting${RunID}@destify.com`,
    );

    cy.get('[data-testid="share-room-modal-button-send"]').click();

    cy.wait('@Invitation').its('response.statusCode').should('eq', 200);

    //TODO

    cy.get('[data-testid="app-alert-button-close"]').click();

    cy.get('[data-testid="app-modal-button-close"] > svg').click();
  });
});
