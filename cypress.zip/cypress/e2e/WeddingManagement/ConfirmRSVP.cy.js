//TODO: Add validation to confirm number of days shown is accuracte (number of days from today until the wedding date)

describe('Confirm RSVPs', () => {
  it('Logs In and validates RSVP', () => {
    cy.visit(Cypress.config('baseUrl'));

    cy.intercept(
      ' https://api.destify-services-staging.com/api/AuthenticateUser',
    ).as('Auth');

    cy.get('[data-testid="sign-up-button-log-in"]').click();

    cy.get('[data-testid="log-in-input-email"]').type('britini@travelzap.com');

    cy.get('[data-testid="log-in-input-password"]').type('britiniandben');

    cy.get('[data-testid="log-in-button-log-in"]').click();

    cy.wait('@Auth');

    // TODO: Update this when /ome os merged
    // cy.url().should('contain', '/')

    // Navigate to Guest List

    cy.get('[data-testid="nav-tabs-wedding-management"]').click();

    cy.get('[data-testid="menu-item-button-rsvps"]').click();

    //TODO

    // Actually confirm RSVP
  });
});
