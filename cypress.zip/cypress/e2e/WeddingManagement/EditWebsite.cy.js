//TODO: Add validation to confirm number of days shown is accuracte (number of days from today until the wedding date)
import { faker } from '@faker-js/faker';
import { createWeddingWebsite } from '../../support/WeddingManagement';

// const brideFirstName = faker.name.firstName('female');
// const groomFirstName = faker.name.firstName('male');

describe('Check Wedding Welcome Screen', () => {
  it('Logs In and registers a domain', () => {});
  cy.visit(Cypress.config('baseUrl'));

  cy.intercept(
    ' https://api.destify-services-staging.com/api/AuthenticateUser',
  ).as('Auth');

  cy.get('[data-testid="sign-up-button-log-in"]').click();

  // cy.get('[data-testid="log-in-input-email"]').type('britini@travelzap.com');

  // cy.get('[data-testid="log-in-input-password"]').type('britiniandben');
  cy.get('[data-testid="log-in-input-email"]').type(
    'Bobby_Stroman9190@gmail.com',
  );

  cy.get('[data-testid="log-in-input-password"]').type(
    'Bobby_Stroman9190@gmail.com',
  );

  cy.get('[data-testid="log-in-button-log-in"]').click();

  cy.wait('@Auth');

  createWeddingWebsite();
});
