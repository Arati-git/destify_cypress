//Checks to see that Guest List Loads Properly and information is visible

//HACK: @GuestList and @Export-GuestList has a user ID GUID in the URL parameter. If User ID changes for test, the associated intercepts will need to be updated. This is fragile
//HACK2: 'Search For Guest' uses the name of a guest in a room in this group. If user changes, then the associated guest will need to be updated. This is fragile

//TODO: add validation for the data shown at the top of the page (Total Guests, Adults, Total Rooms, etc)
//TODO2: Add validation for checking and deleting the downloaded xls spreadsheet.

describe('Check Wedding Welcome Screen', () => {
  it('Logs In and validates Guest List', () => {
    cy.visit(Cypress.config('baseUrl'));

    cy.intercept(
      ' https://api.destify-services-staging.com/api/AuthenticateUser',
    ).as('Auth');

    //HACK

    cy.intercept(
      'https://api.destify-services-staging.com/api/groupleader/4ecce6cb-73cc-34ca-413e-62a2e20a51d2/guestlist',
    ).as('GuestList');

    cy.intercept(
      'https://api.destify-services-staging.com/api/groupleader/4ecce6cb-73cc-34ca-413e-62a2e20a51d2/export-guestlist',
    ).as('Export-GuestList');

    //END HACK

    cy.get('[data-testid="sign-up-button-log-in"]').click();

    cy.get('[data-testid="log-in-input-email"]').type('britini@travelzap.com');

    cy.get('[data-testid="log-in-input-password"]').type('britiniandben');

    cy.get('[data-testid="log-in-button-log-in"]').click();

    cy.wait('@Auth').its('response.statusCode').should('eq', 200);

    // Navigate to Guest List

    cy.get('[data-testid="nav-tabs-wedding-management"]').click();

    cy.get('[data-testid="menu-item-button-guest-list"]').click();

    cy.wait('@GuestList', { timeout: 30000 })
      .its('response.statusCode')
      .should('eq', 200);

    // Test Elements on Guest List Page

    cy.get(
      ':nth-child(1) > .MuiCollapse-wrapper > .MuiCollapse-wrapperInner > .MuiPaper-root > .MuiCardActions-root',
    ).should('be.visible');

    cy.wait(2000);

    cy.get('[data-testid="guest-list-button-show-more-0"]').click();

    cy.wait(1000);

    cy.get('[data-testid="guest-list-button-show-less-0"]').click();

    cy.get('[data-testid="guest-list-button-show-more-1"]').click();

    cy.wait(1000);

    cy.get('[data-testid="guest-list-button-show-less-1"]').click();

    // Search For Guest

    //HACK2

    cy.get('[data-testid="guest-list-input-search"]').type('Britini');

    //END HACK2

    cy.get(
      ':nth-child(1) > .MuiCollapse-wrapper > .MuiCollapse-wrapperInner > .MuiPaper-root > .MuiCardActions-root',
    ).should('not.be.visible');

    // Return to full Guest List

    cy.get('[data-testid="guest-list-input-search"]').clear();

    cy.get(
      ':nth-child(1) > .MuiCollapse-wrapper > .MuiCollapse-wrapperInner > .MuiPaper-root > .MuiCardActions-root',
    ).should('be.visible');

    // Download Guest Spreadsheet

    cy.get('[data-testid="guest-list-button-download-spreadsheet"]').click();

    cy.wait('@Export-GuestList', { timeout: 30000 })
      .its('response.statusCode')
      .should('eq', 200);
  });
});
