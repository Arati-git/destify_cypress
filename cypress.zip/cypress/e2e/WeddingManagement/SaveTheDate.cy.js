//TODO: Add validation to confirm number of days shown is accuracte (number of days from today until the wedding date)

describe('Check Wedding Welcome Screen', () => {
  it('Logs In and registers a domain', () => {
    cy.visit(Cypress.config('baseUrl'));

    cy.intercept(
      ' https://api.destify-services-staging.com/api/AuthenticateUser',
    ).as('Auth');

    cy.testid('sign-up-button-log-in').click();

    cy.testid('log-in-input-email').type('britini@travelzap.com');

    cy.testid('log-in-input-password').type('britiniandben');

    cy.testid('log-in-button-log-in').click();

    cy.wait('@Auth');

    // Navigate to Wedding Website page

    cy.testid('nav-tabs-wedding-management').click();

    cy.testid('menu-item-button-wedding-website').click();

    cy.url().should('contain', '/wedding-website');
    cy.contains('Save the Date');

    // Save the Date
    cy.testid('save-the-date-button').click();

    cy.testid('save-the-date-select-button').click();

    // Choose image
    cy.testid('save-the-date-modal-image-0').click();

    // Save image
    cy.testid('save-the-date-modal-save-button').click();

    //generate image
    cy.testid('save-the-date-generate-image-button').click();

    cy.wait(2000);

    // Download image
    cy.testid('image-download-modal-button').click();

    //Close modal
    cy.testid('app-modal-button-close').click();

    // Delete Save the Date
    cy.testid('save-the-date-delete-image-button').click();

    // cy.testid('edit-website-button').click();

    // View Website
    // cy.testid('view-website-button').click();
  });
});
