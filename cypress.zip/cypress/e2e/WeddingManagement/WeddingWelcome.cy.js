//Checks to see that Welcome Screen is visable for Group Leaders

//TODO: Add validation to confirm number of days shown is accuracte (number of days from today until the wedding date)

describe('Check Wedding Welcome Screen', () => {
  it('Logs In and validates Welcome Screen visibility', () => {
    cy.visit(Cypress.config('baseUrl'));

    cy.intercept(
      ' https://api.destify-services-staging.com/api/AuthenticateUser',
    ).as('Auth');

    cy.get('[data-testid="sign-up-button-log-in"]').click();

    cy.get('[data-testid="log-in-input-email"]').type(
      'product+CypressWedding@destify.com',
    );

    cy.get('[data-testid="log-in-input-password"]').type(
      'product+CypressWedding@destify.com',
    );

    cy.get('[data-testid="log-in-button-log-in"]').click();

    cy.wait('@Auth');

    cy.url().should('contain', '/welcome');

    // Validate Welcome Screen is visable

    cy.get('.welcomeContainer').should('be.visible');

    cy.get('.horizontalGradient').should('be.visible');

    cy.get('.stepsContainer').should('be.visible');

    cy.get('.counter').should('be.visible');

    //TODO
  });
});
