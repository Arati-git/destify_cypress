export function loginToAdmin() {
  cy.origin('https://www.destifyadmin.zapgas.dev', () => {
    cy.visit('pages/login', { failOnStatusCode: false });
    // check if we are on the login page. if not, we are already logged in
  });
  // HACK - admin doesn't reliably take us to the login page, so we have to check
  cy.url().then(url => {
    if (url.includes('/login')) {
      cy.get('.btn-login').click();
      cy.origin('https://auth.zapgas.dev', () => {
        // cy.visit(
        //   'https://auth.zapgas.dev/Account/Login?ReturnUrl=%2Fconnect%2Fauthorize%2Fcallback%3Fclient_id%3Dptidadminclient%26redirect_uri%3Dhttps%253A%252F%252Fwww.destifyadmin-stage.destify.com%252Fsignin-oidc%26response_type%3Dcode%26scope%3Dopenid%2520email%2520profile%2520role%2520ptidadminapi%26state%3De750a4b1bd4c47098944ac2606244108%26code_challenge%3DoZcxnCwMAQlEkDXfFDljjx7TttXcWiUNeSY88wmkDJM%26code_challenge_method%3DS256%26response_mode%3Dquery',
        // );
        cy.get('#signInFormUsername').type('travelzapuser@travelzap.com', {
          force: true,
        });
        cy.get('#signInFormPassword').type('Nepal@123456', { force: true });
        cy.get('[type="submit"]').click({ force: true, multiple: true });
      });
    }
  });
}

export function _approveWeddingDate(name) {
  cy.origin('https://www.destifyadmin.zapgas.dev', () => {
    cy.request(
      'POST',
      'https://destifyadmin-api-stage.destify.com/api/SalesLead/SalesLeadAll',
      {
        IsSortAsc: true,
        PageNumber: 1,
        PageSize: 10,
        sortBy: '',
        ResortID: 0,
        venuID: 0,
        leadTypeID: 0,
        WeddingDateStatusID: 0,
        Search: [
          {
            columnSearchName: 'FullName',
            columnSearchValue: name,
          },
        ],
      },
    ).then(response => {
      console.log(response);
      const salesLeadID = response.body[0].id;
      cy.log(salesLeadID);
      cy.request(
        'PUT',
        'https://destifyadmin-api-stage.destify.com/api/SalesLead/SalesLeadWeddingDateUpdate',
        {
          SalesLeadID: salesLeadID,
          weddingDateStatus: 2,
        },
      );
    });
  });
}

export function _approveAlternativeWeddingDate(name) {
  cy.origin('https://www.destifyadmin.zapgas.dev', () => {
    cy.request(
      'POST',
      'https://destifyadmin-api-stage.destify.com/api/SalesLead/SalesLeadAll',
      {
        IsSortAsc: true,
        PageNumber: 1,
        PageSize: 10,
        sortBy: '',
        ResortID: 0,
        venuID: 0,
        leadTypeID: 0,
        WeddingDateStatusID: 0,
        Search: [
          {
            columnSearchName: 'FullName',
            columnSearchValue: name,
          },
        ],
      },
    ).then(response => {
      console.log(response);
      const salesLeadID = response.body[0].id;
      cy.log(salesLeadID);
      cy.request(
        'PUT',
        'https://destifyadmin-api-stage.destify.com/api/SalesLead/SalesLeadWeddingDateUpdate',
        {
          SalesLeadID: salesLeadID,
          weddingDateStatus: 2,
        },
      );
    });
  });
}

// export function _changeUserRole(id) {
//   cy.origin('https://www.destifyadmin.zapgas.dev'', () => {
//     cy.request(
//       'POST',
//       'https://api.destify-services-staging.com/api/user/switchUserRole',
//       {
//         userId: id,
//         assignRole: 'GroupLeader',
//       },
//     ).then(response => {
//       console.log('response from admin', response);
//     });
//   });
// }

export function changeUserRole(email) {
  loginToAdmin();
  cy.testid('button-client-account').click();
  cy.testid('input-email').type(email);
  cy.testid('dropdown-toggle').click();
  cy.testid('make-group-leader').click();

  cy.get(
    'body > div.sweet-alert.showSweetAlert.visible > div.sa-button-container > div > button',
  ).click({ multiple: true });
}
