function _createSalesJourneyAccount(RunID) {
  cy.visit(Cypress.config('baseUrl'));
  cy.request(
    'POST',
    'https://salesjourney-staging.destify-services.com/api/Auth/register',
    {
      confirmPassword: 'CypressIsFun1!',
      country: 'US',
      email: `product+Cy${RunID}@destify.com`,
      firstName: 'AutomatedTest',
      lastName: RunID,
      password: 'CypressIsFun1!',
      phoneNumber: '+1 (234) 567-8910',
      state: 'Alabama',
    },
  );
}
