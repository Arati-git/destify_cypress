import { _selectReservationDatesLiveBooking } from './LiveBooking';
import { _selectReservationDates } from './SalesJourney';

export function selectRoom(flow) {
  cy.log('Search Room');
  if (flow === 'ptid') {
    _selectReservationDates();
  } else {
    _selectReservationDatesLiveBooking();
  }
  cy.testid('step-search-room-input-guests').click();
  cy.testid('step-search-room-button-accept').click();

  cy.testid('search-room-button').click();

  cy.wait('@Availability').its('response.statusCode').should('eq', 200);

  cy.get('.select-room-0').contains('Select').click();

  cy.clickNextButton();
}

export function enterTravelerDetails({ firstName, lastName, email }) {
  cy.log('Enter Traveler Details');

  cy.testid('traveler-form-0-input-first-name').type(firstName);

  cy.testid('traveler-form-0-input-last-name').type(lastName);

  cy.testid('traveler-form-0-input-email').type(email);

  cy.testid('traveler-form-0-input-phone').type('1234567890');

  cy.testid('traveler-form-0-input-birthdate').type('01/01/1990');
  cy.testid('traveler-form-0-gender').parent().click();
  cy.contains('Female').click();

  cy.clickNextButton();

  // cy.wait('@Transfers').its('response.statusCode').should('eq', 200);
}

export function fillInStripeForm({ firstName, lastName }) {
  cy.getStripeElement(
    'input[data-elements-stable-field-name="cardNumber"]',
    '4111111111111111',
  );
  cy.getStripeElement(
    'input[data-elements-stable-field-name="cardExpiry"]',
    '1025',
  );
  cy.getStripeElement(
    'input[data-elements-stable-field-name="cardCvc"]',
    '123',
  );
  cy.getStripeElement(
    'input[data-elements-stable-field-name="postalCode"]',
    '90210',
  );

  cy.testid('payment-form-input-first-name').type(firstName);
  cy.testid('payment-form-input-last-name').type(lastName);

  cy.testid('payment-form-select-state').click();
  cy.get('li[data-value="Utah"]').click();

  // creates a random address
  const uuid = () => Cypress._.random(0, 1e6);
  const id = uuid();
  const randomAddress = `${id} Main St`;

  cy.testid('payment-form-input-city').type('Park City');
  cy.testid('payment-form-input-street-address').type(randomAddress);

  // dribble on the canvas
  cy.testid('payment-form-input-signature')
    .trigger('mousedown', { clientX: 30, clientY: 100 })
    .trigger('mouseover')
    .trigger('mousedown', { which: 1 })
    .trigger('mousemove', { clientX: 125, clientY: 50 })
    .trigger('mousemove', { clientX: 150, clientY: 75 })
    .trigger('mousemove', { clientX: 200, clientY: 25 })
    .trigger('mousemove')
    .trigger('mouseup', { force: true });

  // cy.pause();
  cy.testid('payment-form-checkbox-is-terms-accepted').check();

  cy.testid('payment-form-button-make-payment').click();
  cy.wait(3000);
}

export function selectsRoomExtras({ roomExtras = false }) {
  if (roomExtras) {
    cy.testid('step-room-extras-button-transfer-0').click();
  }
  cy.clickNextButton();
}

export function confirmSuccessfulPayment() {
  cy.wait('@CaptureCharge').its('response.statusCode').should('eq', 200);
  cy.wait('@Recheck').its('response.statusCode').should('eq', 200);
  cy.wait('@Book').its('response.statusCode').should('eq', 200);
  cy.wait('@CreateRoom').its('response.statusCode').should('eq', 200);
  cy.wait('@AddUserGroupInformation')
    .its('response.statusCode')
    .should('eq', 200);
  cy.wait('@CreatePayment').its('response.statusCode').should('eq', 200);
  cy.wait('@SignatureUpload').its('response.statusCode').should('eq', 200);
}
