import {
  daysAfter,
  daysBefore,
  areDifferentMonths,
  convertDateToMUIDatePickerDisplayFormat,
} from './utils';

import { Interception } from 'cypress/types/net-stubbing';

export function entersLiveBooking(groupId) {
  cy.visit(`http://localhost:3000/live-booking/${groupId}`);
}

export function createAccountLiveBooking({ firstName, lastName, email }) {
  cy.testid('button-create-account').click();
  cy.log('Creates Account');
  cy.testid('sign-up-input-first-name').should('exist').type(firstName);
  cy.testid('sign-up-input-last-name').type(lastName);
  cy.testid('sign-up-input-email').type(email);
  console.log(`%c ${email}`, 'color: green; font-size: 30px');
  cy.testid('sign-up-button-sign-up').click();
  cy.testid('sign-up-input-phone').type('2345678910');
  cy.testid('sign-up-select-state').parent().click();
  cy.contains('Illinois').click();
  cy.testid('sign-up-button-sign-up').click();
  cy.testid('sign-up-input-password').type(email);
  cy.testid('sign-up-input-confirm-password').type(email);
  cy.testid('sign-up-button-sign-up').click();
  cy.wait('@Register').its('response.statusCode').should('eq', 200);
  cy.wait('@Authenticate').its('response.statusCode').should('eq', 200);
}

export function enterGuestDashboard() {
  cy.testid('button-view-itinerary').click();
}

export function confirmUserDataLoaded() {
  cy.wait('@UserTrips').its('response.statusCode').should('eq', 200);
  cy.wait('@Groups').its('response.statusCode').should('eq', 200);
  cy.wait('@Rooms').its('response.statusCode').should('eq', 200);
}

export function _selectReservationDatesLiveBooking() {
  cy.log('Select Reservation Dates');
  // wait until group details are loaded
  // then, get the wedding date
  // then, calculate check in and check out dates
  // then, click on the check in and check out dates on the date pickers;
  cy.wait('@WeddingInfo').its('response.statusCode').should('eq', 200);
  cy.wait('@GroupInfo').then((interception: Interception) => {
    //@ts-ignore
    assert(
      interception?.response?.statusCode === 200,
      '/GroupDetails should return group details',
    );

    const weddingDate = new Date(
      //@ts-ignore
      interception.response.body.weddingDate,
    );

    const checkInDate = daysBefore(weddingDate, 2);
    const checkInDateToClick =
      convertDateToMUIDatePickerDisplayFormat(checkInDate);

    const checkOutDate = daysAfter(weddingDate, 2);
    const checkOutDateToClick =
      convertDateToMUIDatePickerDisplayFormat(checkOutDate);

    const formattedWeddingDate = weddingDate;

    cy.wait(1000);
    // click on the check in date field
    cy.testid('range-calendar-input-start').click();

    // if dates are in different months, click the previous month button
    if (areDifferentMonths(checkInDate, formattedWeddingDate)) {
      cy.testid('ArrowLeftIcon').click();
    }

    // click on the check in date based on the aria-label
    cy.get(`[aria-label="${checkInDateToClick}"]`).first().click();

    //click ok
    cy.testid(`confirm-date`).click();

    // click on the check out date field
    cy.testid('range-calendar-input-end').click();

    // if dates are in different months, click the next month button
    if (areDifferentMonths(checkOutDate, formattedWeddingDate)) {
      cy.testid('ArrowRightIcon').click();
    }
    // click on the check out date based on the aria-label
    cy.get(`[aria-label="${checkOutDateToClick}"]`).first().click();

    //click ok);
    cy.testid(`confirm-date`).click();
  });
}
