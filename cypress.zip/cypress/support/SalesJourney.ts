import { Interception } from 'cypress/types/net-stubbing';

import {
  daysAfter,
  daysBefore,
  areDifferentMonths,
  convertDateToMUIDatePickerDisplayFormat,
} from './utils';
import {
  confirmSuccessfulPayment,
  enterTravelerDetails,
  fillInStripeForm,
  selectRoom,
  selectsRoomExtras,
} from './Common';
import { _approveWeddingDate, loginToAdmin } from './Admin';

const RunID = Math.floor(Math.random() * 1000);
const SJAPI = Cypress.env('SJAPI');
const DSAPI = Cypress.env('DSAPI');
const DSAPI_AWS = Cypress.env('DSAPI_AWS');

const randomNumber = Math.floor(Math.random() * 100);

// const password = faker.internet.password();

// const firstName = faker.name.firstName();
// const lastName = faker.name.lastName();
// // randomNumber in case the generated email doesn't have a number - required for password
// const email = faker.internet.email(
//   `${firstName}_${lastName}${randomNumber}_cypressTest`,
// );

export function interceptAndAliasAllRequests() {
  const requests = {
    CitiesList: `${SJAPI}/City/*`,
    ResortsList: `${SJAPI}/Resort/*`,
    CountryList: `${SJAPI}/Country/*`,
    VenuesList: `${SJAPI}/ResortVenue/*`,
    WeddingPackage: `${SJAPI}/WeddingPackage/*`,
    PreferredCeremonyTime: `${SJAPI}/SalesLead/PreferredCeremonyTime`,
    UpdateWeddingDetails: `${SJAPI}/WeddingDetails/UpdateWeddingDetails/*`,
    GetUserDetails: `${SJAPI}/Auth/GetUserDetails`,
    WeddingRoleList: `${SJAPI}/WeddingDetails/WeddingRoleList`,
    // SalesLeadMenu: `${SJAPI}/SalesLead/SalesLeadMenu`,
    SalesLeadPage: `${SJAPI}/SalesLead/SalesLeadPage?ShowWeddingDateAvailable=false`,
    SalesLeadSave: `${SJAPI}/SalesLead/SalesLeadSave`,
    UserProgress: `${SJAPI}/Auth/UserProgress`,
    Register: `${SJAPI}/Auth/register`,
    GroupDetails: `${SJAPI}/GroupManagement/GroupDetails`,
    ChangeUserRole: `${DSAPI_AWS}/user/switchUserRole`,
    Availability: `${DSAPI_AWS}/hotel/availability`,
    Transfers: `${DSAPI_AWS}/transfer/hotelTransfersByCrmHotelId/*`,
    // ChangeUserRole: `${DSAPI_AWS}/user/switchUserRole`,
    // Payment Endpoints
    CaptureCharge: `${DSAPI_AWS}/stripe/capturecharge/*`,
    Recheck: `${DSAPI_AWS}/hotel/recheck`,
    Book: `${DSAPI_AWS}/hotel/book`,
    CreateRoom: `${DSAPI_AWS}/rooms/createRoom`,
    AddUserGroupInformation: `${DSAPI_AWS}/user/addUserGroupInformation/*/*/*`,
    CreatePayment: `${DSAPI_AWS}/payment/createPayment`,
    SignatureUpload: `${DSAPI_AWS}/payment/signature-upload`,
    CMSCreateSite: `${DSAPI_AWS}/site/CMSCreateSite`,
    GetWebsiteInfo: `${DSAPI_AWS}/Site/CMSGetWebsiteInfo`,
  };
  //iterate over requests and intercept and alias each request
  Object.keys(requests).forEach(alias => {
    cy.intercept(requests[alias], req => {
      console.log('Request body:', req.body);
    }).as(alias);
  });
}

export function entersSalesView() {
  cy.log('Visits Site');
  cy.visit(Cypress.config('baseUrl'));

  cy.testid('sign-up-button-sign-up').click();

  cy.testid('sign-up-as-button-plan-my-destination-wedding').click();

  cy.clickNextButton();
}

export function selectsDestination() {
  cy.log('Selects Destination');

  // cy.wait('@CountryList').its('response.statusCode').should('eq', 200);

  cy.testid('card-button-select-0').click();

  cy.clickNextButton();
}

export function selectsCity() {
  cy.log('Selects City');

  // cy.wait('@CitiesList').its('response.statusCode').should('eq', 200);

  cy.testid('card-button-select-0').click();
  cy.testid('card-button-select-1').click();

  cy.clickNextButton();
}

export function selectsAnticipatedWeddingDate() {
  cy.log('Selects Anticipated Wedding Date');

  cy.testid('anticipated-wedding-date-input-date').click();

  cy.testid('ArrowRightIcon').click();
  cy.testid('ArrowRightIcon').click();
  cy.testid('ArrowRightIcon').click();
  cy.testid('ArrowRightIcon').click();
  cy.testid('ArrowRightIcon').click();
  cy.testid('ArrowRightIcon').click();

  cy.get('button.MuiPickersDay-root').eq(15).click();

  cy.get('.MuiDialogActions-root > :nth-child(2)').click();
}

export function selectsResort(pricingType: 'static_pricing' | 'live_pricing') {
  //HACK we need to distinguish between static and live pricing.
  //This is a temporary solution until we can get the pricing type from the API
  // if (pricingType === 'static_pricing') {
  cy.log('Selects Resort');
  selectsAnticipatedWeddingDate();

  cy.wait('@ResortsList').then((interception: Interception) => {
    console.log({ interception });
    //@ts-ignore
    assert(
      interception?.response?.statusCode === 200,
      '/Resorts should return a list of resorts',
    );
    //@ts-ignore
    const resorts = interception.response.body.data;
    const staticResort = resorts.filter((resort: any, idx) => {
      return (
        resort.resortName.includes('Dreams') ||
        resort.resortName.includes('Hilton') ||
        resort.resortName.includes('Palace')
      );
    })[0];

    const livePricedResort = resorts.filter((resort: any, idx) => {
      return (
        !resort.resortName.includes('Dreams') &&
        !resort.resortName.includes('Hilton') &&
        !resort.resortName.includes('Palace')
      );
    })[0];

    const index = resorts.indexOf(
      pricingType === 'static_pricing' ? staticResort : livePricedResort,
    );
    cy.log(
      'selecting a static resort: ',
      staticResort.resortName,
      'index: ',
      index,
    );
  });

  cy.wait(2000);

  cy.testid('card-button-select-1').click();

  cy.clickNextButton();
}

export function selectsVenue() {
  cy.log('Selects Venue');

  cy.wait('@VenuesList').its('response.statusCode').should('eq', 200);

  cy.testid('card-button-select-0').click();

  cy.clickNextButton();
}

export function selectsPackage() {
  cy.log('Selects Wedding Package');

  cy.wait('@WeddingPackage').its('response.statusCode').should('eq', 200);

  cy.testid('card-button-select-0').click();

  cy.clickNextButton();
}

export function selectsWeddingDate() {
  cy.log('Selects Wedding Date');

  cy.wait('@PreferredCeremonyTime')
    .its('response.statusCode')
    .should('eq', 200);

  cy.testid('open-picker-button').first().click();

  cy.get('button.MuiPickersDay-root').eq(15).click();

  cy.testid('step-date-button-ok').click();

  cy.testid('open-picker-button').eq(1).click();

  cy.get('button.MuiPickersDay-root').eq(16).click();

  cy.testid('step-alt-date-button-ok').click();

  cy.clickNextButton();
}

export function createsAccount(firstName, lastName, email) {
  cy.log('Creates Account');

  cy.clickNextButton();

  cy.testid('sign-up-as-plan-input-first-name').should('exist').type(firstName);

  cy.testid('sign-up-as-plan-input-last-name').type(lastName);

  cy.testid('sign-up-as-plan-input-email').type(email);

  console.log(`%c ${email}`, 'color: green; font-size: 30px');

  cy.testid('sign-up-as-plan-button-sign-up').click();

  cy.testid('sign-up-as-plan-input-phone').type('2345678910');

  cy.testid('phone-country-select').click();

  cy.testid('country-option-US').click();

  // cy.testid('sign-up-as-plan-select-state').click();

  // cy.get('.MuiList-root > [tabindex="0"]').click();

  cy.testid('sign-up-as-plan-button-sign-up').click();

  cy.testid('sign-up-as-plan-input-password').type(email);

  cy.testid('sign-up-as-plan-input-confirm-password').type(email);

  cy.testid('sign-up-as-plan-button-sign-up').click();

  cy.wait('@Register').its('response.statusCode').should('eq', 200);
}

export function entersProfileDetails({ email, firstName, lastName }) {
  cy.log('Enters Profile Details', email);

  // cy.wait('@PreferredCeremonyTime')
  //   .its('response.statusCode')
  //   .should('eq', 200);

  selectsAnticipatedWeddingDate();

  cy.wait('@WeddingRoleList').its('response.statusCode').should('eq', 200);

  cy.testid('details-input-spouse-1-full-name').type(
    firstName + ' ' + lastName,
  );

  cy.testid('details-input-spouse-2-full-name').type('Spouse Cypress');

  cy.wait(3000);
  cy.testid('details-button-submit').click();
}

export function entersGuestDetails() {
  cy.log('Enters Guest Details');

  cy.testid('details-slider-guest-rail').click('center');

  cy.testid('details-radio-travel-information-option-0').click();

  cy.testid('details-radio-is-staying-resort-option-0').click();

  cy.testid('details-radio-is-minimum-nights-option-0').click();
  cy.wait(3000);

  cy.testid('details-button-submit').click();
}

export function entersPreferences() {
  cy.log('Enters Preferences');

  cy.testid('details-radio-luxury-option-3').click();

  cy.testid('details-radio-budget-option-4').click();
}

export function submitsPreferences() {
  cy.log('Submits Preferences');
  cy.wait(3000);
  cy.testid('details-button-submit').click();
  cy.wait('@UpdateWeddingDetails').its('response.statusCode').should('eq', 200);
}

export function submitsWeddingRequest() {
  cy.log('Submits Wedding Request');

  cy.wait('@UserProgress').its('response.statusCode').should('eq', 200);
  cy.wait(3000);
  // cy.testid('menu-item-button-explore').click();
  cy.clickNextButton();
}

export function confirmsSuccessfulWeddingRequest() {
  cy.log('Confirm Successful Wedding Request');
  //wait for @salesleadsave for 10000ms
  cy.wait('@SalesLeadSave', { timeout: 15000 })
    .its('response.statusCode')
    .should('eq', 200);

  cy.wait('@GetUserDetails').its('response.statusCode').should('eq', 200);

  cy.wait('@UserProgress').its('response.statusCode').should('eq', 200);
}

export function enterReservationsView() {
  cy.log('Enter Reservations View');

  cy.wait('@GetUserDetails', { timeout: 20000 })
    .its('response.statusCode')
    .should('eq', 200);

  cy.testid('home-button-keep-exploring').click();

  cy.testid('start-reservation').click();

  cy.testid('button-start').click();

  // cy.testid('step-confirm-button-find-your-room').click();
}

export function _assignUserAsGroupLeader() {
  cy.wait('@UpdateWeddingDetails', { timeout: 20000 }).then(interception => {
    const userId = interception?.response?.body?.data;
    console.log('userId', userId);

    // _changeUserRole(userId);
  });
}
export function _selectReservationDates() {
  cy.log('Select Reservation Dates');
  // wait until group details are loaded
  // then, get the wedding date
  // then, calculate check in and check out dates
  // then, click on the check in and check out dates on the date pickers;

  cy.wait('@GroupDetails').then((interception: Interception) => {
    //@ts-ignore
    assert(
      interception?.response?.statusCode === 200,
      '/GroupDetails should return group details',
    );

    const weddingDate = new Date(
      //@ts-ignore
      interception.response.body.data.weddingEventDate,
    );

    const checkInDate = daysBefore(weddingDate, 3);
    const checkInDateToClick =
      convertDateToMUIDatePickerDisplayFormat(checkInDate);

    const checkOutDate = daysAfter(weddingDate, 2);
    const checkOutDateToClick =
      convertDateToMUIDatePickerDisplayFormat(checkOutDate);

    const formattedWeddingDate = weddingDate;

    cy.wait(2000);
    // click on the check in date field
    cy.testid('range-calendar-input-start').click();

    // if dates are in different months, click the previous month button
    if (areDifferentMonths(checkInDate, formattedWeddingDate)) {
      cy.testid('ArrowLeftIcon').click();
    }

    // click on the check in date based on the aria-label
    cy.get(`button[aria-label="${checkInDateToClick}"]`).first().click();

    //click ok
    cy.testid(`confirm-date`).click();

    // // click on the check out date field
    cy.testid('range-calendar-input-end').click();

    // if dates are in different months, click the next month button
    if (areDifferentMonths(checkOutDate, formattedWeddingDate)) {
      cy.testid('ArrowRightIcon').click();
    }
    // click on the check out date based on the aria-label
    cy.get(`button[aria-label="${checkOutDateToClick}"]`).first().click();

    //click ok);
    cy.testid(`confirm-date`).click();
  });
}

export function bookAWedding({
  pricingType,
  firstName,
  lastName,
  email,
  roomExtras,
}: {
  pricingType: 'static_pricing' | 'live_pricing';
  firstName: string;
  lastName: string;
  email: string;
  roomExtras: boolean;
}) {
  //intercept all requests and alias them here
  interceptAndAliasAllRequests();
  //begin sales journey
  entersSalesView();
  selectsDestination();
  selectsCity();
  selectsResort(pricingType);
  selectsVenue();
  selectsPackage();
  selectsWeddingDate();
  createsAccount(firstName, lastName, email);
  entersProfileDetails({ firstName, lastName, email });
  entersGuestDetails();
  entersPreferences();
  submitsPreferences();
  submitsWeddingRequest();
  confirmsSuccessfulWeddingRequest();
  // keeping these in case we need to test for resorts that require manual approval in admin
  loginToAdmin();
  _approveWeddingDate(firstName + ' ' + lastName);
  cy.visit(Cypress.config('baseUrl'));
  // loginAs('product+Cy511488@destify.com', 'product+Cy511488@destify.com');
  enterReservationsView();
  selectRoom('ptid');
  enterTravelerDetails({ firstName, lastName, email });
  selectsRoomExtras({ roomExtras: false });
  cy.clickNextButton();
  fillInStripeForm({ firstName, lastName });
  confirmSuccessfulPayment();
}

export function createAccountThenSubmitWeddingRequest({
  firstName,
  lastName,
  email,
}: {
  firstName: string;
  lastName: string;
  email: string;
}) {
  //intercept all requests and alias them here
  interceptAndAliasAllRequests();
  //begin sales journey
  entersSalesView();
  createsAccount(firstName, lastName, email);
  entersProfileDetails({ firstName, lastName, email });
  entersGuestDetails();
  entersPreferences();
  submitsPreferences();
  cy.clickNextButton();
  selectsDestination();
  selectsCity();
  selectsResort('static_pricing');
  selectsVenue();
  selectsPackage();
  selectsWeddingDate();
  submitsWeddingRequest();
  confirmsSuccessfulWeddingRequest();
}
