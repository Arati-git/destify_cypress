export function createWeddingWebsite(brideFirstName, groomFirstName) {
  // Navigate to Wedding Website page

  cy.get('[data-testid="nav-tabs-wedding-management"]').click();

  cy.get('[data-testid="menu-item-button-wedding-website"]').click();

  cy.url().should('contain', '/wedding-website');

  // This checks if a domain has been registered
  // If not, it fills domain and register
  // Else, continues with editing website
  cy.testid('wedding-website-input-site-name').type(
    `${brideFirstName}and${groomFirstName}Testtest`,
  );

  cy.testid('wedding-website-button-register-website').click();

  cy.testid('wedding-website-button-yes').click();

  cy.wait('@CMSCreateSite').its('response.statusCode').should('eq', 200);
}
