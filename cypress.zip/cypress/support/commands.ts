/// <reference types="cypress" />
/// <reference types="@testing-library/cypress" />
// ***********************************************
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
import '@testing-library/cypress/add-commands';
export {};
declare global {
  namespace Cypress {
    interface Chainable {
      /**
       * Clicks an active Next button in Sales Journey. Takes an alias for cy.wait().its('response.statusCode').should('eq', 200) if needed. Make sure to declare the interception before this function to use this.
       * Example: clickNextButton('@Resort')
       * @param {string} alias - The alias of the inteception route to wait on.
       */
      clickNextButton(alias?: string);
      /**
       * Creates an account in the sales journey. No params
       */
      createSalesJourneyAccount();
      testid(value: string);
      getStripeElement(selector, value);
      chooseDatePicker(selector: string, value: string);
    }
  }
}

Cypress.Commands.add('clickNextButton', alias => {
  cy.get('[data-testid="button-next"]')
    .should('exist')
    .should('be.enabled')
    .click();

  if (alias) cy.wait(`${alias}`).its('response.statusCode').should('eq', 200);
});

Cypress.Commands.add('testid', value => {
  return cy.get(`[data-testid=${value}]`);
});

Cypress.Commands.add('getStripeElement', (selector, value) => {
  cy.get('iframe')
    .should(iframe => expect(iframe.contents().find(selector)).to.exist)
    .then(iframe => cy.wrap(iframe.contents().find(selector)))
    .within(input => {
      cy.wrap(input).should('not.be.disabled').clear().type(value);
    });
});
