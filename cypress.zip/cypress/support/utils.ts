import { faker } from '@faker-js/faker';

export function daysBefore(date, numDays) {
  // Create a new date object by subtracting the number of days from the passed in date
  const newDate = new Date(date.getTime() - numDays * 24 * 60 * 60 * 1000);
  return newDate;
}
export function daysAfter(date, numDays) {
  // Create a new date object by adding the number of days from the passed in date
  const newDate = new Date(date.getTime() + numDays * 24 * 60 * 60 * 1000);
  return newDate;
}

export function areDifferentMonths(date1, date2) {
  return date1.getMonth() !== date2.getMonth();
}

export function convertDateToMUIDatePickerDisplayFormat(date) {
  const formattedDate = date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
  return formattedDate;
}

export function makeFakeUser() {
  const randomNumber = Math.floor(Math.random() * 100);
  const firstName = faker.name.firstName();
  const lastName = `${faker.name.lastName()}TESTUSER`;
  const email = `${firstName}_${randomNumber}${lastName}@destify.com`;
  const fakeUser = {
    firstName,
    lastName,
    email,
  };
  return fakeUser;
}

// Use this function to log in as a user at a specific point in the sales journey to troubleshoot a step
export function loginAs(username: string, password: string) {
  cy.visit(Cypress.config('baseUrl'));

  cy.testid('sign-up-button-log-in').click();

  cy.testid('log-in-input-email').type(username);

  cy.testid('log-in-input-password').type(password);

  cy.testid('log-in-button-log-in').click();
}
